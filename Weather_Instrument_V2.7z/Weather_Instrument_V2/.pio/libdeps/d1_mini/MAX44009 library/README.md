# MAX44009
Arduino library for the MAX44009 luxmeter chip used in the popular CJMCU breakout boards.

<img src="https://github.com/dantudose/misc/blob/master/max44009.jpg" height="300"/>

Revision history:
1. rev. 1.0.0 - added support for Wire library
2. rev. 1.0.1 - fixed initialization bug
3. rev. 1.0.2 - fixed lux reading mode
